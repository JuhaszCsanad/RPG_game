let profil={
    "btn":document.getElementById("profil_btn"),
    "page":document.getElementById("profil_pg")
}
let games={
    "btn":document.getElementById("games_btn"),
    "page":document.getElementById("games_pg")
}
let par={
    "btn":document.getElementById("parok_btn"),
    "page":document.getElementById("parok_pg")
}
function init(){
    valtas_profil();
}
function valtas_profil(){
    profil.btn.style.display="none";
    profil.page.style.display="block";
    games.btn.style.display="inline";
    games.page.style.display="none";
    par.btn.style.display="inline";
    par.page.style.display="none";
}
function valtas_games(){
    profil.btn.style.display="inline";
    profil.page.style.display="none";
    games.btn.style.display="none";
    games.page.style.display="block";
    par.btn.style.display="inline";
    par.page.style.display="none";
}
function valtas_parok(){
    profil.btn.style.display="inline";
    profil.page.style.display="none";
    games.btn.style.display="inline";
    games.page.style.display="none";
    par.btn.style.display="none";
    par.page.style.display="block";
}
init();