let stats={
    "hp":100,
    "str":10,
    "def":10,
    "exp":0,
    "chr":5
}
let profil_stats={
    "hp": document.getElementById("karakter_hp"),
    "str": document.getElementById("karakter_str"),
    "def":document.getElementById("karakter_def"),
    "exp": document.getElementById("karakter_exp"),
    "pics": document.getElementById("profil_pics"),
    "chr":document.getElementById("karakter_chr")
}
let lvl=0;
let available_points=0;
let profil_pics_and_exp=[
    ["profil_lvl0.jpg",50],
    ["profil_lvl1.jpg",100],
    ["profil_lvl2.jpg",175],
    ["profil_lvl3.jpg",250]
]
function refreshstats(){
    profil_stats.hp.innerHTML=stats.hp;
    profil_stats.str.innerHTML=stats.str;
    profil_stats.def.innerHTML=stats.def;
    profil_stats.chr.innerHTML=stats.chr;
    profil_stats.exp.innerHTML=stats.exp+"/"+profil_pics_and_exp[lvl][1];
    profil_stats.pics.src="pics/"+profil_pics_and_exp[lvl][0];
    lvlup();
}
refreshstats();

//Szint lépés//
function lvlup(){
    if(stats.exp>=profil_pics_and_exp[lvl][1]){
        available_points+=3;
        lvl++;
        addBtn();
        refreshstats();
    }
    else{
        addBtn();
    }
}
function lvlupFORTEST(){
    stats.exp+=10;
    refreshstats();
}
//PLusz gomb megjelenítés//
function addBtn(){
    let AddBtn=document.getElementsByClassName("addBtn")
    if(available_points>0){
        for(let i=0; i<AddBtn.length; i++){
            const element=AddBtn[i];
            element.style.display="inline";
            
        }        
    }
    else{
        for(let i=0; i<AddBtn.length; i++){
            const element=AddBtn[i];
            element.style.display="none";
            
        }    
    }
}
//Stats növelés//
function plus_hp(){
    available_points--;
    stats.hp+=5;
    refreshstats();
    addBtn();
}
function plus_str(){
    available_points--;
    stats.str+=5;
    refreshstats();
    addBtn();
}
function plus_def(){
    available_points--;
    stats.def+=5;
    refreshstats();
    addBtn();
}
function plus_chr(){
    available_points--;
    stats.chr+=5;
    refreshstats();
    addBtn();
}
//Vadászat//
let story=document.getElementById("story");
function random(){
    return Math.floor(Math.random()*100);
}
function vadaszat(){
    let rnd=random();
    if(rnd<20){
        story.innerHTML+="Nem találtál semmit!<br>";
        refreshstats();
    }
    else{
        harc("Vaddisznó",50,6,15,"Macska",20,2,5);
        refreshstats();
    }
}
function harc(e_name,e_hp,e_damage,max_e_exp){
    story.innerHTML+="Szembe jött egy "+e_name+" és levadászod!<br>";
    do {
        story.innerHTML+="~~~~~~~<br>"
        let rnd=random();
        if (rnd<50) {
            story.innerHTML+="Te támadsz!<br>";
            e_hp-=stats.str;    
            refreshstats();       
            story.innerHTML+="Megsebzed a "+e_name+"-t! (-"+stats.str+"hp)<br>";
            story.innerHTML+=e_name+"-nak/nek "+e_hp+" élete maradt!<br>"
        } else {
            story.innerHTML+="A "+e_name+" támad!<br>";
            stats.hp-=e_damage;
            refreshstats();
            story.innerHTML+="A "+e_name+" megsebez téged! (-"+e_damage+"hp)<br>";
            story.innerHTML+=stats.hp+" életed maradt!<br>"
        }
    } while (e_hp>0 && stats.hp>0);

    if (e_hp<=0) {
        story.innerHTML+="Megölted a "+e_name+"-t!<br>";
        let exp=Math.floor(Math.random()*max_e_exp)+5;
        stats.exp+=exp;
        story.innerHTML+="Kaptál "+exp+" tapasztalat pontot!<br>";
        refreshstats();
    } else {
        story.innerHTML+="Megölt téged a "+e_name+". Szégyen az egész családodra!<br>";
        refreshstats();
    }
}
//Párkapcsolat//
function Beatrix(){
    if (stats.chr<10) {
        storyy.innerHTML+="Beatrixnak nem tetszett hogy zaklatod és a családi ékszeren rugott! (-5hp)<br>";
        storyy.innerHTML+="Nem vagy elég karizmatikus e hölgy számára!<br>";
        stats.hp-=5;
        refreshstats();
    }
    if (stats.chr>=10 && stats.chr<20) {
        storyy.innerHTML+="Beatrix finoman vissza utasított egy pofonnal! (-1hp és egy törött szív)<br>";
        storyy.innerHTML+="Már majdnem elég karizmatikus vagy e hölgy számára!<br>";
        stats.hp-=1;
        refreshstats();
    }
    if(stats.chr>=20){
        storyy.innerHTML+="Beatrixnak tetszel és veled töltött egy estét! (+1hp és egy törött ágy)<br>"
        stats.hp+=1;
        refreshstats();
    }
}
function Felicia(){
    if (stats.chr<10) {
        storyy.innerHTML+="Felíciának nem tetszett hogy zaklatod és a családi ékszeren rugott! (-5hp)<br>";
        storyy.innerHTML+="Nem vagy elég karizmatikus e hölgy számára!<br>";
        stats.hp-=5;
        refreshstats();
    }
    if (stats.chr>=10 && stats.chr<20) {
        storyy.innerHTML+="Felícia finoman vissza utasított egy pofonnal! (-1hp és egy törött szív)<br>";
        storyy.innerHTML+="Már majdnem elég karizmatikus vagy e hölgy számára!<br>";
        stats.hp-=1;
        refreshstats();
    }
    if(stats.chr>=20){
        storyy.innerHTML+="Felíciának tetszel és veled töltött egy estét! (+1hp és egy törött ágy)<br>"
        stats.hp+=1;
        refreshstats();
    }
}